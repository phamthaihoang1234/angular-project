create
    definer = root@localhost procedure select_all_products()
begin
    select * from products
        limit 1, 8;
end;

